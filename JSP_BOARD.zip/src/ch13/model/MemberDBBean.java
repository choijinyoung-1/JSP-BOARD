package ch13.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class MemberDBBean {
	private static MemberDBBean instance = new MemberDBBean();
	public static MemberDBBean getInstance() {
		return instance;
	}
	private MemberDBBean() {}
	
	 private Connection getConnection() throws Exception {
			Context initCtx= new InitialContext();
			Context envCtx = (Context)initCtx.lookup("java:comp/env");
			DataSource ds = (DataSource)envCtx.lookup("jdbc/oracledb");
	    	return ds.getConnection();
	 }

	 public int insertMember(MemberDataBean article) throws Exception  {
			int result = 0;
			Connection conn = null;
			PreparedStatement pstmt = null;
			String sql = "";
			try {
				conn = getConnection();	
				sql="INSERT INTO MEMBER VALUES"
				+ " (?, ?, '', ?, '', '', ?, SYSTIMESTAMP)";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, article.getId());
				pstmt.setString(2, article.getPasswd());
				pstmt.setString(3, article.getEmail());
				pstmt.setString(4, article.getName());
				
				result = pstmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				closeDBResources(pstmt, conn);
			}
			return result;
	 }
	 public String checkIdPw(String id) throws Exception {
	    	String dbpasswd = null;
	    	Connection conn = null;
	        PreparedStatement pstmt = null;
	        ResultSet rs= null;
	        try {
				conn = getConnection();
	            pstmt = conn.prepareStatement(
	            	"select passwd from member where id = ?");
	            pstmt.setString(1, id);
	            rs = pstmt.executeQuery();
	            
				if(rs.next()){
					dbpasswd= rs.getString("passwd"); 
				}
	        } catch(Exception ex) {
	            ex.printStackTrace();
	        } finally {
	        	closeDBResources(rs, pstmt, conn);
	        }
	    	return dbpasswd;
	    }
	 public MemberDataBean getArticleInfo(String id) throws Exception {
		 Connection conn = null;
		 PreparedStatement pstmt = null;
		 ResultSet rs = null;
		 MemberDataBean article = null;
		 try {
			 conn = getConnection();
			 
			 pstmt = conn.prepareStatement("select email,name from member where id = ?");
			 pstmt.setString(1, id);
			 rs = pstmt.executeQuery();
			 
			 if(rs.next()) {
				 article = new MemberDataBean();
				 article.setEmail(rs.getString("email"));
				 article.setName(rs.getString("name"));
			 }
			 
		 } catch(Exception e) {
			 e.printStackTrace();
		 } finally {
			 closeDBResources(rs, pstmt, conn);
		 }
		 return article;
	 }

	private void closeDBResources(ResultSet rs, Statement stmt, Connection conn) {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	private void closeDBResources(ResultSet rs, PreparedStatement pstmt, Connection conn) {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	private void closeDBResources(PreparedStatement pstmt, Connection conn) {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	private void closeDBResources(Statement stmt, Connection conn) {
			if (stmt != null) {
				try {
					stmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	private void closeDBResources(ResultSet rs, PreparedStatement pstmt) {
			if (rs != null) {
				try {
					rs.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	private void closeDBResources(PreparedStatement pstmt) {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}


	}




